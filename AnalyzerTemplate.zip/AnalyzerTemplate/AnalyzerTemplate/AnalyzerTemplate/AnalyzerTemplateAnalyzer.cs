﻿using System.Collections.Immutable;
using System.Diagnostics;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Diagnostics;

namespace AnalyzerTemplate
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class AnalyzerTemplateAnalyzer : DiagnosticAnalyzer
    {
        public const string DiagnosticId = "AnalyzerTemplate";

        private static readonly LocalizableString Title = new LocalizableResourceString(nameof(Resources.AnalyzerTitle), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString MessageFormat = new LocalizableResourceString(nameof(Resources.AnalyzerMessageFormat), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString Description = new LocalizableResourceString(nameof(Resources.AnalyzerDescription), Resources.ResourceManager, typeof(Resources));
        private const string Category = "Naming";

        private static readonly DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: Description);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get { return ImmutableArray.Create(Rule); } }

        public override void Initialize(AnalysisContext context)
        {
            Debugger.Launch();
            context.RegisterSyntaxNodeAction(c =>
            {
                var nullTokens = c.Node.DescendantTokens().Where(
                    token => token.IsKind(SyntaxKind.NullKeyword) && token.Text == "null");
                
                var nullToken = nullTokens.FirstOrDefault(
                    token => IsCollectionMethod(token));

                if (nullToken != null)
                {
                    var diag = Diagnostic.Create(Rule, nullToken.GetLocation(), nullToken.Text);
                    c.ReportDiagnostic(diag);
                }
            },
            SyntaxKind.ReturnStatement);

            context.RegisterSyntaxNodeAction(c =>
            {
                var nullTokens = c.Node.DescendantTokens().Where(
                    token => token.IsKind(SyntaxKind.NullKeyword) && token.Text == "null");

                var nullToken = nullTokens.FirstOrDefault(
                    token => IsIEnumerableCollectionMethod(token));

                if (nullToken != null)
                {
                    var diag = Diagnostic.Create(Rule, nullToken.GetLocation(), nullToken.Text);
                    c.ReportDiagnostic(diag);
                }
            },
            SyntaxKind.YieldReturnStatement);
        }
        
        private bool IsCollectionMethod(SyntaxToken initialToken)
        {
            var methodNode = initialToken.Parent.Ancestors().FirstOrDefault(node => node.IsKind(SyntaxKind.MethodDeclaration));

            if (methodNode == null) return false;

            var returnedGenericOrArrayTypeNode = methodNode.DescendantNodes().FirstOrDefault(
                node => node.IsKind(SyntaxKind.GenericName) || node.IsKind(SyntaxKind.ArrayType));

            if (returnedGenericOrArrayTypeNode == null) return false;

            if (returnedGenericOrArrayTypeNode.IsKind(SyntaxKind.ArrayType)) return true;

            return IsListOrIEnumerable(returnedGenericOrArrayTypeNode);
        }

        private bool IsIEnumerableCollectionMethod(SyntaxToken initialToken)
        {
            var methodNode = initialToken.Parent.Ancestors().FirstOrDefault(node => node.IsKind(SyntaxKind.MethodDeclaration));

            if (methodNode == null) return false;

            var genericOrArrayTypeNode = methodNode.DescendantNodes().FirstOrDefault(node =>
            {
                if (!node.IsKind(SyntaxKind.GenericName)) return false;
                if (node.ChildTokens().FirstOrDefault(token => token.Text == "IEnumerable") == null) return false;

                var returnedGenericNode = node.DescendantNodes().FirstOrDefault(
                    returnedNode => returnedNode.IsKind(SyntaxKind.GenericName) || returnedNode.IsKind(SyntaxKind.ArrayType));
                return returnedGenericNode != null;
            });

            if (genericOrArrayTypeNode == null) return false;

            if (genericOrArrayTypeNode.IsKind(SyntaxKind.ArrayType)) return true;

            return IsListOrIEnumerable(genericOrArrayTypeNode);
        }

        private bool IsListOrIEnumerable(SyntaxNode genericNode)
        {
            return genericNode.ChildTokens().FirstOrDefault(
                    token => token.Text == "IEnumerable" || token.Text == "List") != null;
        }
    }
}