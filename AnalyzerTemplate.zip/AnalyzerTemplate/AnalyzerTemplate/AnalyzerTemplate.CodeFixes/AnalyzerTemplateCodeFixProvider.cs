﻿using System;
using System.Collections.Immutable;
using System.Composition;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AnalyzerTemplate
{
    [ExportCodeFixProvider(LanguageNames.CSharp, Name = nameof(AnalyzerTemplateCodeFixProvider)), Shared]
    public class AnalyzerTemplateCodeFixProvider : CodeFixProvider
    {
        public const string title = "Remove null.";
        public sealed override ImmutableArray<string> FixableDiagnosticIds
        {
            get { return ImmutableArray.Create(AnalyzerTemplateAnalyzer.DiagnosticId); }
        }

        public sealed override FixAllProvider GetFixAllProvider()
        {
            // See https://github.com/dotnet/roslyn/blob/main/docs/analyzers/FixAllProvider.md for more information on Fix All Providers
            return WellKnownFixAllProviders.BatchFixer;
        }

        public sealed override async Task RegisterCodeFixesAsync(CodeFixContext context)
        {
            var document = context.Document;
            var root = await document.GetSyntaxRootAsync();
            var diagnostic = context.Diagnostics.First();
            if (diagnostic == null) throw new Exception("Diagnostic is null");
            var diagnosticSpan = diagnostic.Location.SourceSpan;
            var node = root.FindNode(diagnosticSpan);

            context.RegisterCodeFix(
                CodeAction.Create(
                    title: CodeFixResources.CodeFixTitle,
                    createChangedDocument: async c =>
                    {
                        var createMethodAccessExpression = SyntaxWithNew(Primer());

                        var updatedRoot = root.ReplaceNode(node, createMethodAccessExpression);

                        return document.WithSyntaxRoot(updatedRoot);
                    },
                    equivalenceKey: nameof(CodeFixResources.CodeFixTitle)),
                diagnostic);
        }

        private static SyntaxNode SyntaxWithNew(TypeSyntax node)
        {
            return SyntaxFactory.ObjectCreationExpression(node);
        }



        /*private static TypeSyntax TypeInsideCollectionMethod(SyntaxNode methodNode)
        {
            var methodNode = initialToken.Parent.Ancestors().FirstOrDefault(node => node.IsKind(SyntaxKind.MethodDeclaration));

            if (methodNode == null) throw new Exception("It isn't method.");

            var returnedGenericNode = methodNode.DescendantNodes().FirstOrDefault(node => node.IsKind(SyntaxKind.GenericName));

            if (returnedGenericNode == null) throw new Exception("It isn't generic method.");
        }

        private static SyntaxNode TypeInsideIEnumerableCollectionsMethod(SyntaxNode methodNode)
        {
            var methodNode = initialToken.Parent.Ancestors().FirstOrDefault(node => node.IsKind(SyntaxKind.MethodDeclaration));

            if (methodNode == null) throw new Exception("It isn't method.");

            var genericNode = methodNode.DescendantNodes().FirstOrDefault(node =>
            {
                if (!node.IsKind(SyntaxKind.GenericName)) throw new Exception("It isn't IEnumerable method.");
                var returnedGenericNode = node.DescendantNodes().FirstOrDefault(returnedNode => returnedNode.IsKind(SyntaxKind.GenericName));
                return returnedGenericNode != null;
            });

            if (genericNode == null) throw new Exception("It isn't IEnumerable generic method.");
        }*/
        
        private TypeSyntax Primer()
        {
            return SyntaxFactory.GenericName(
                        SyntaxFactory.Identifier("List")
                    )
                    .WithTypeArgumentList(
                        SyntaxFactory.TypeArgumentList(
                            SyntaxFactory.SingletonSeparatedList<TypeSyntax>(
                                SyntaxFactory.PredefinedType(
                                    SyntaxFactory.Token(SyntaxKind.IntKeyword)
                                )
                            )
                        )
                    );
        }

        private SyntaxNode Primer2()
        {
            return SyntaxFactory.CompilationUnit()
            .WithMembers(
                SyntaxFactory.SingletonList<MemberDeclarationSyntax>(
                    SyntaxFactory.GlobalStatement(
                        SyntaxFactory.ExpressionStatement(
                            SyntaxFactory.ObjectCreationExpression(
                                SyntaxFactory.GenericName(
                                    SyntaxFactory.Identifier("Ienumerable")
                                )
                                .WithTypeArgumentList(
                                    SyntaxFactory.TypeArgumentList(
                                        SyntaxFactory.SingletonSeparatedList<TypeSyntax>(
                                            SyntaxFactory.GenericName(
                                                SyntaxFactory.Identifier("List")
                                            )
                                            .WithTypeArgumentList(
                                                SyntaxFactory.TypeArgumentList(
                                                    SyntaxFactory.SingletonSeparatedList<TypeSyntax>(
                                                        SyntaxFactory.GenericName(
                                                            SyntaxFactory.Identifier("Dictionary")
                                                        )
                                                        .WithTypeArgumentList(
                                                            SyntaxFactory.TypeArgumentList(
                                                                SyntaxFactory.SeparatedList<TypeSyntax>(
                                                                    new SyntaxNodeOrToken[]{
                                                                        SyntaxFactory.PredefinedType(
                                                                            SyntaxFactory.Token(SyntaxKind.IntKeyword)
                                                                        ),
                                                                        SyntaxFactory.Token(SyntaxKind.CommaToken),
                                                                        SyntaxFactory.PredefinedType(
                                                                            SyntaxFactory.Token(SyntaxKind.FloatKeyword)
                                                                        )
                                                                    }
                                                                )
                                                            )
                                                        )
                                                    )
                                                )
                                            )
                                        )
                                    )
                                )
                            )
                            .WithArgumentList(
                                SyntaxFactory.ArgumentList()
                            )
                        )
                    )
                )
            )
            .NormalizeWhitespace();
        }

        private static MemberAccessExpressionSyntax CreateMemberAccessExpression(string accessExpression)
        {
            var parts = accessExpression.Split('.');

            if (parts.Length < 2)
                throw new Exception("There should at least be two parts.");

            var memberAccessExpression =
                        SyntaxFactory.MemberAccessExpression(
                            SyntaxKind.SimpleMemberAccessExpression,
                            SyntaxFactory.IdentifierName(parts[0]),
                            SyntaxFactory.IdentifierName(parts[1]));

            for (int i = 2; i < parts.Length; i++)
            {
                memberAccessExpression =
                        SyntaxFactory.MemberAccessExpression(
                            SyntaxKind.SimpleMemberAccessExpression,
                            memberAccessExpression,
                            SyntaxFactory.IdentifierName(parts[i]));
            }

            return memberAccessExpression;
        }
    }
}
